"""Define funcoes que vao mudar o mundo."""


def media(a, b):
    """Calcula a media de dois numeros."""
    return (a + b) / 2

print(media(2, 2))
